import React from 'react';
import './App.css';

const Contact = () => {
  const contactInfo = {
    email: 'info@sharada-sanskrit-ocr.com',
    phone: '+1 (555) 555-5555',
    address: '123 Main St, Anytown USA 12345'
  };

  return (
    <div className="container">
      <div className="box">
        <h2>Contact</h2>
        <p>
          Email: <a href={`mailto:${contactInfo.email}`}>{contactInfo.email}</a>
        </p>
        <p>
          Phone: <a href={`tel:${contactInfo.phone}`}>{contactInfo.phone}</a>
        </p>
        <p>
          Address: {contactInfo.address}
        </p>
      </div>
    </div>
  );
};

export default Contact;
