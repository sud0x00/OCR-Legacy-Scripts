import React from 'react';

const Header = (props) => {
    return (
        <header>
            <button className="search-button" onClick={() => props.handleButtonClick("search")}>Search</button>
            <button className="faq-button" onClick={() => props.handleButtonClick("faq")}>FAQ</button>
            <button className="contact-button" onClick={() => props.handleButtonClick("contact")}>Contact</button>
        </header>
    )
}

export default Header;
