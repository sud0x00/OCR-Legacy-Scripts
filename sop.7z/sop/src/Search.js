import React from 'react';

const Search = ({ handleChange, handleSubmit }) => {

  return (
    <div className="search-section">
      <h2>Search</h2>
      <form onSubmit={handleSubmit}>
        <label>
          Upload Image:
          <input type="file" name="image" accept="image/*" onChange={(e) => handleChange(e.target.files[0])} />
        </label>
        <button type="submit">Search</button>
      </form>
    </div>
  )
}

export default Search;
