import React from 'react';
import './App.css';

const FAQ = () => {
  const questions = [
    {
      question: 'What is Sharada to Sanskrit OCR?',
      answer: 'Sharada to Sanskrit OCR is a tool for converting written Sharada script to Sanskrit text.'
    },
    {
      question: 'How does the OCR work?',
      answer: 'The OCR works by using computer vision and machine learning algorithms to recognize and transcribe written Sharada script into Sanskrit text.'
    },
    {
      question: 'What types of images can be used for OCR?',
      answer: 'The OCR can be used with any image that contains written Sharada script, as long as the text is clear and legible.'
    },
    {
      question: 'Is the OCR accurate?',
      answer: 'The OCR has a high degree of accuracy, but the results may not be perfect. The accuracy may be affected by factors such as the quality of the image, the handwriting, and the complexity of the script.'
    }
  ];

  return (
    <div className="container">
      <div className="box">
        <h2>FAQ</h2>
        {questions.map(({ question, answer }, index) => (
          <div key={index}>
            <h3>{question}</h3>
            <p>{answer}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default FAQ;
