import React, { useState } from 'react';

function MainUI() {
  const [ocrResult, setOcrResult] = useState(null);
  const [image, setImage] = useState(null);

  const handleImageUpload = (event) => {
    setImage(event.target.files[0]);
  };

  const handleOcr = async () => {
    if (!image) {
      alert("Please select an image");
      return;
    }

    const formData = new FormData();
    formData.append("image", image);

    const response = await fetch("/ocr", {
      method: "POST",
      body: formData,
    });
    const result = await response.json();
    setOcrResult(result);
  };

  return (
    <div>
      <header>
        <nav>
          {/* Navigations links to FAQ and Contact pages */}
        </nav>
      </header>
      <main>
        <form>
          <input type="file" onChange={handleImageUpload} />
          <button type="button" onClick={handleOcr}>
            Perform OCR
          </button>
        </form>
        <section>
          {ocrResult ? <pre>{JSON.stringify(ocrResult, null, 2)}</pre> : null}
        </section>
      </main>
    </div>
  );
}

export default MainUI;
