import React, { useState } from 'react';
import { Link, Element, Events, animateScroll as scroll, scrollSpy, scroller } from 'react-scroll';
import Header from './Header';
import Search from './Search';
import Result from './Result';
import FAQ from './FAQ';
import Contact from './Contact';
import './styles.css';

function App() {
  const [activeButton, setActiveButton] = useState("search");
  const [image, setImage] = useState(null);
  const [links, setLinks] = useState(null);

  const handleButtonClick = (button) => {
    setActiveButton(button);
    if(button !== "search"){
      scroll.scrollTo(activeButton);
    }
  }

  const handleSubmit = (e) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append('image', image);
    fetch('http://localhost:5000/upload', {
      method: 'POST',
      body: formData
    })
    .then(response => response.json())
    .then(data => {
      setLinks(data);
      handleButtonClick("result");
    })
    .catch(error => {
      console.error(error);
    });
  }

  return (
    <div className="app">
      <Header handleButtonClick={handleButtonClick} />
      <div className="main-content">
        <Element name="search">
          {activeButton === "search" && <Search handleChange={setImage} handleSubmit={handleSubmit} />}
        </Element>
        <Element name="result">
          {activeButton === "result" && <Result links={links} />}
        </Element>
        <Element name="faq">
          {activeButton === "faq" && <FAQ />}
        </Element>
        <Element name="contact">
          {activeButton === "contact" && <Contact />}
        </Element>
      </div>
    </div>
  )
}

export default App;